const LocationReport = ({
  data,
}) => {

  return (
    <div className="bg-white p-5 rounded-xl shadow">

      <h2 className="text-2xl font-bold mb-5">
        Location Report
      </h2>

      <div className="overflow-auto">

        <table className="w-full">

          <thead>

            <tr className="border-b">

              <th className="py-3 text-left">
                Location
              </th>

              <th className="py-3 text-left">
                Total Customers
              </th>

              <th className="py-3 text-left">
                Active Customers
              </th>

              <th className="py-3 text-left">
                Total Due
              </th>

            </tr>

          </thead>

          <tbody>

            {
              data?.villages?.map(
                (item, index) => (

                  <tr
                    key={index}
                    className="border-b"
                  >

                    <td className="py-3 font-semibold">
                      {item._id}
                    </td>

                    <td className="py-3">
                      {item.totalCustomers}
                    </td>

                    <td className="py-3 text-green-600 font-bold">
                      {item.activeCustomers}
                    </td>

                    <td className="py-3 text-red-500 font-bold">
                      ₹ {item.totalDue}
                    </td>

                  </tr>
                )
              )
            }

          </tbody>

        </table>

      </div>

    </div>
  );
};

export default LocationReport;