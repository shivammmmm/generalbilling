import { useState } from "react";

import CustomerForm from "../../components/farmers/FarmerForm";

import API from "../../services/api";

import toast from "react-hot-toast";

import { useNavigate } from "react-router-dom";

const AddCustomer = () => {

  const navigate = useNavigate();

  const [loading, setLoading] =
    useState(false);

  const addCustomer = async (
    formData
  ) => {

    try {

      setLoading(true);

      await API.post(
        "/farmers",
        formData
      );

      toast.success(
        "Customer added successfully"
      );

      navigate("/farmers");

    } catch (error) {

      toast.error(
        error.response?.data?.message
      );

    } finally {

      setLoading(false);

    }
  };

  return (
    <div>

      <h1 className="text-3xl font-bold mb-5">
        Add Customer
      </h1>

      <CustomerForm
        onSubmit={addCustomer}
        loading={loading}
      />

    </div>
  );
};

export default AddCustomer;