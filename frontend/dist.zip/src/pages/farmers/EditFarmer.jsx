import {
  useEffect,
  useState,
} from "react";

import {
  useParams,
  useNavigate,
} from "react-router-dom";

import API from "../../services/api";

import CustomerForm from "../../components/farmers/FarmerForm";

import toast from "react-hot-toast";

const EditCustomer = () => {

  const { id } = useParams();

  const navigate = useNavigate();

  const [farmer, setCustomer] =
    useState(null);

  const [loading, setLoading] =
    useState(false);

  // ================= GET SINGLE =================

  const getCustomer = async () => {

    try {

      const { data } =
        await API.get(
          `/farmers/${id}`
        );

      setCustomer(data.farmer);

    } catch (error) {
      console.log(error);
    }
  };

  // ================= UPDATE =================

  const updateCustomer = async (
    formData
  ) => {

    try {

      setLoading(true);

      await API.put(
        `/farmers/${id}`,
        formData
      );

      toast.success(
        "Customer updated"
      );

      navigate("/farmers");

    } catch (error) {

      toast.error(
        error.response?.data?.message
      );

    } finally {

      setLoading(false);

    }
  };

  useEffect(() => {
    getCustomer();
  }, []);

  if (!farmer) {
    return <h1>Loading...</h1>;
  }

  return (
    <div>

      <h1 className="text-3xl font-bold mb-5">
        Edit Customer
      </h1>

      <CustomerForm
        initialData={farmer}
        onSubmit={updateCustomer}
        loading={loading}
      />

    </div>
  );
};

export default EditCustomer;